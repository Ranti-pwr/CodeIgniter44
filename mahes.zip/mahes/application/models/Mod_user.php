<?php
class Mod_user extends CI_Model {

	function all() {
	
	}

    public function sim() {
		
	}
}
