<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

    public function __construct() {
        parent::__construct();
        // Load model dan library yang dibutuhkan
        $this->load->model('admin_model');
        $this->load->library('session');
    }

    public function index() {
        // Tampilkan halaman login
        $this->load->view('admin/login');
    }

    public function login() {
        // Tangkap data dari form login
        $username = $this->input->post('username');
        $password = $this->input->post('password');
        
        // Lakukan validasi login di sini dengan model admin_model
        $admin = $this->admin_model->get_admin_by_credentials($username, $password);
        
        if ($admin) {
            // Simpan data admin ke session jika login berhasil
            $this->session->set_userdata('admin_id', $admin['id']);
            redirect('admin/dashboard'); // Ganti dengan halaman dashboard admin
        } else {
            // Jika login gagal, tampilkan pesan error
            $data['error_message'] = 'Username atau password salah';
            $this->load->view('admin/login', $data);
        }
    }

    public function logout() {
        // Hapus data admin dari session dan redirect ke halaman login
        $this->session->unset_userdata('admin_id');
        redirect('adminauth');
    }
}
