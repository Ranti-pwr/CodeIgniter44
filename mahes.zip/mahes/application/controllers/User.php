<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class User extends CI_Controller {

	public function index()
	{
		$qury = $this->db->select('*')->from('user')->order_by('nama', 'ASC')->get()->result_array();
        $data = array('user' => $qury);
		$this->load->view('user', $data);
	}

    public function tambah()
	{
		$this->load->view('user_tam');
	}
    
    public function simpan()
	{
		$data= array(
            'username' => $this->input->post('username'),
            'nama' => $this->input->post('nama'),
            'password' => md5($this->input->post('password')),
            'level' => $this->input->post('level'),
        );

        $this->db->insert('user', $data);
        redirect('user');
	}

    // function delete($id_user){
    //     $qury = $this->db->where('id_user', $id_user)->delete('user');
    //     redirect('user');
    //    }
}
