<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<title>User</title>
	<?php require_once('layout/2css.php'); // CSS ?>
</head>

<body>
	<div class="container-xxl position-relative bg-white d-flex p-0">
		<!-- Spinner Start -->
		<div id="spinner"
			class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
			<div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
				<span class="sr-only">Memuat...</span>
			</div>
		</div>
		<!-- Spinner End -->
		<?php require_once('layout/2sidebar.php'); //  Sidebar?>
		<!-- Content Start -->
		<div class="content">
			<?php require_once('layout/2navbar.php') // Navbar ?>
			<div class="container-fluid pt-4 px-4">
            <a class="btn btn-success m-2" href="<?php base_url('user/tambah'); ?>">Tambah User</a>
				<div class="bg-light rounded h-100 p-4">
					<h6 class="mb-4">Data User</h6>
					<div class="table-responsive">
						<table class="table">
							<thead>
								<tr>
									<th scope="col">#</th>
									<th scope="col">Username</th>
									<th scope="col">Nama</th>
									<th scope="col">Level</th>
									<th scope="col">Aksi</th>
									
								</tr>
							</thead>
							<tbody>
                                <?php
								$no=1; 
								foreach($user as $u) { ?>
								<tr>
									<th scope="row">1</th>
									<td><?= $u['username'] ?></td>
									<td><?= $u['nama'] ?></td>
									<td><?= $u['level'] ?></td>
									<td>
										<a class="btn btn-primary m-2" href="#" onclick="return confirm('Hapus data?');"><i class="bi bi-pencil-square"></i></a>
										<a class="btn btn-primary m-2" href="<?= base_url('user/delete/'.$key->id_user) ?>" onclick="return confirm('Hapus data?');"><i class="bi bi-trash"></i></a>
									</td>
								</tr>
                                <?php  $no++;} ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
			<?php require_once('layout/2footer.php'); // Footer ?>
		</div>
		<!-- Content End -->
		<!-- Back to Top -->
		<a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
	</div>
	<?php require_once('layout/2js.php'); // Javascript ?>
</body>

</html>